<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=".css"/>
	<title>Práctica 2</title>

	<!--h1-->
    

    <!--label-->
    
    
    <!--legend-->
    

    <!--button-->
</head>
<body>
	<h1 align="center">Edición de datos</h1>

    <fieldset>
    <legend>Buscar id</legend>
    <table>

    <tr>
    <form action="Buscar idclientes.php" method="POST">
        <label>ID:</label><br>
        <input type="text" class="form-control" placeholder="Id" name="Id"><br>

        <button type="submit" class="btn btn-primary">Ver datos</button><br>
    </form>
    </tr>

    </table>
    </fieldset>
</body>
</html>