<?php
require_once("Cookies.php");
//session_destroy() destruye toda la información asociada con la sesión actual.
destruir_session();
?>
