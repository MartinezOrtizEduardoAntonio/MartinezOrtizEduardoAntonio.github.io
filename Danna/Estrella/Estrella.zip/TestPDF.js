function print_facture(name, description, price, date) {
    //obtenemos los valores de los inputs del formulario 
    var valorUno = document.querySelector('input[name="uno"]').value;
    var valorDos = document.querySelector('input[name="dos"]').value;
    var valorTres = document.querySelector('input[name="tres"]').value;
    var valorCuatro = document.querySelector('input[name="cuatro"]').value;
    var valorCinco = document.querySelector('input[name="cinco"]').value;
    var valorSeis = document.querySelector('input[name="seis"]').value;
    var valorSiete = document.querySelector('input[name="siete"]').value;
    var valorOcho = document.querySelector('input[name="ocho"]').value;
    var valorNueve = document.querySelector('input[name="nueve"]').value;
    var valorDiez = document.querySelector('input[name="diez"]').value;
    var valorOnce = document.querySelector('input[name="once"]').value;
    var valorDoce = document.querySelector('input[name="doce"]').value;
    var valorTrece = document.querySelector('input[name="trece"]').value;

    // Definir la estructura del documento PDF
    var docDefinition = {
        content: [
            { text: 'Factura', style: 'header' },
            { text: 'Name: ' + valorUno },
            { text: 'Name: ' + valorDos },
            { text: 'Name: ' + valorTres },
            { text: 'Name: ' + valorCuatro },
            { text: 'Name: ' + valorCinco },
            { text: 'Name: ' + valorSeis },
            { text: 'Name: ' + valorSiete },
            { text: 'Name: ' + valorOcho },
            { text: 'Name: ' + valorNueve },
            { text: 'Name: ' + valorDiez },
            { text: 'Name: ' + valorOnce },
            { text: 'Name: ' + valorDoce },
            { text: 'Name: ' + valorTrece },
        ],
        styles: {
            header: {
                fontSize: 18,
                bold: true,
                margin: [0, 0, 0, 10]
            }
        }
    };

    // Generar el documento PDF
    pdfMake.createPdf(docDefinition).download('factura.pdf');
}
