<?php
    function este_usuario_existe($username,$password){
        /*$server="127.0.0.1:3306";
        $username="u280687855_Xeno";
        $password="v[aTd8C:";
        $database="u280687855_examen2";
        
        $connection=mysqli_connect($server,$username,$password,$database) or die("Problemas en la conexion".mysqli_error($conexion));*/
        
        $connection=mysqli_connect("localhost","root","","bd1") or die("error to connection with the database");

        $consulta = "SELECT * FROM `usuarios` WHERE username='$username' and password='$password'";
	    $result = mysqli_query($conexion, $consulta)or die('La consulta fallo;: ' . mysql_error());


        if($valores = mysqli_fetch_array($resultado)){
            mysqli_close($conexion);
            return true;
        }else{
            mysqli_close($conexion);
            return false;
        }
    }

    function crear_session($username){
        session_start();

        $_SESSION["username"] = $username;
    }

    function destruir_session(){
        session_start();

        session_unset();

        session_destroy();

        header("Location: ingreso.php");
        exit();
    }

    function crear_cookies($usuario){
        $segundo = 60;
        $minuto = 1;
        $hora = 1;
        $dias = 1;
        $duracion_cookie =  $segundo * $minuto * $hora * $dias;

        setcookie("usuario_recordado", $usuario, time() + $duracion_cookie, "/");
    }

    function destruir_cookies(){
        if(isset($_COOKIE["usuario_recordado"])){
            setcookie("usuario_recordado", "", time() - 3600, "/");
            echo "La cookie fue eliminada exitosamente :D";
        }       
    }
?>
