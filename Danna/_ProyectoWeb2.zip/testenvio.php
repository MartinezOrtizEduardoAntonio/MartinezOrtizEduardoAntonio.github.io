<?php
if(isset($_POST['submit'])){
    $para = "179996@upslp.edu.mx";
    $asunto = "Enviando informacion";
    $RespuestaUno = $_POST['uno'];
    $RespuestaDos = $_POST['dos'];
    $RespuestaTres = $_POST['tres'];
    $RespuestaCuatro = $_POST['cuatro'];
    $RespuestaCinco = $_POST['cinco'];
    $RespuestaSeis = $_POST['seis'];
    $RespuestaSiete = $_POST['siete'];
    $RespuestaOcho = $_POST['ocho'];
    $RespuestaNueve = $_POST['nueve'];
    $RespuestaDiez = $_POST['diez'];
    $RespuestaOnce = $_POST['once'];
    $RespuestaDoce = $_POST['doce'];
    $RespuestaTrece = $_POST['trece'];
    $headers = "MINE-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf8\r\n";
    $cuerpo = " 
        Respuestas de test: $RespuestaUno\n 
        $RespuestaDos\n
        $RespuestaTres\n
        $RespuestaCuatro\n
        $RespuestaCinco\n 
        $RespuestaSeis\n 
        $RespuestaSiete\n 
        $RespuestaOcho\n 
        $RespuestaNueve\n 
        $RespuestaDiez\n 
        $RespuestaOnce\n 
        $RespuestaDoce\n 
        $RespuestaTrece\n
    ";

    $bool = mail($para,$asunto,$cuerpo,$headers);
}else{
    echo "Hubo un error con el envio";
}
?>