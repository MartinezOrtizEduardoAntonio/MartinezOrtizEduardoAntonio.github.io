<?php
    require_once("funciones.php"); // cargarmos el archivo de funcion
    destruir_session();
?>
